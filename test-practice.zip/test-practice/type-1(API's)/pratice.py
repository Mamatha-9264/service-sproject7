items =[]

def get_items():
    if not items:
        return "no items"
    return items
    
def add_items(payload = None):
    if not payload:
        return "Post required data to be added"
    
    items.append(payload)
    return "item added successfully"

def handle(request , payload=None):

    method , path = request.split()

    try:
        if method =="GET" and path == "/items":
            return get_items()
        elif method =="POST" and path =="/items":
            return add_items(payload) 

        else:
            return f"invalid route: {method} {path}"
    except Exception as e:
        return f"Error: {e}" 
    
# print(handle("POST /items", {'book': 1}))
print(handle("POST /items",{"name":"shibu"}))
print(handle("GET /items"))
print(handle("DELETE /items"))