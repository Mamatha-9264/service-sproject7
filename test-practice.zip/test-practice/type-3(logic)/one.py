# Example input
data = [45, 67, 89, 23, 56]

# Step 1: Compute average
avg = sum(data) / len(data)

# Step 2: Apply classification rules
if avg >= 80:
    status = "Excellent"
elif avg >= 60:
    status = "On Track"
elif avg >= 40:
    status = "At Risk"
else:
    status = "Failing"

# Step 3: Output
print("Average:", avg)
print("Category:", status)
